document.addEventListener('DOMContentLoaded', function() {
    const localite = localStorage.getItem('localite');
    if (localite) {
        chargerDonnees(localite);
    } else {
        chargerDonnees(); // Charge toutes les offres si aucune localité spécifique n'est stockée
    }
});

function chargerDonnees(localite = '') {
    console.log("Filtrage par localité:", localite);
    var url = "http://localhost:3000/donnees";
    if (localite.trim() !== "") {
        url += "?Localite=" + encodeURIComponent(localite.trim());
    }

    console.log("URL appelée:", url);

    var http = new XMLHttpRequest();
    http.open("GET", url, true);
    http.setRequestHeader("Content-type", "application/json");

    http.onreadystatechange = function() {
        if(http.readyState == 4 && http.status == 200) {
            var responseData = JSON.parse(http.responseText);
            var jobs = responseData;
            var htmlContent = "<div class='jobs-container'>";
            var result = `<h2><center> Résultats de vos recherches... ${jobs.length} résultat(s) <span class='material-symbols-outlined add-icon'  >add_circle</span> </center></h2>`;
            
            jobs.forEach(function(job, i) {
                htmlContent += "<div class='job-box'>";
                htmlContent += `<h3>${job.TitreDuStage || 'Stage disponible'}</h3>`;
                htmlContent += "<div class='info-container'>";
                htmlContent += `<p><span class='material-symbols-outlined'>location_on</span> ${job.Localite}</p>`;
                htmlContent += `<p><span class='material-symbols-outlined'>calendar_month</span> ${new Date(job.DateOffre).toLocaleDateString()}</p>`;
                htmlContent += `<p><span class='material-symbols-outlined'>description</span> ${job.DescriptionDuStage || 'Description indisponible'}</p>`;
                htmlContent += "</div>";
                htmlContent += "<a href='details.html' class='voir-offre-btn' target='_blank'>Voir l'offre</a>";
                htmlContent += `<p> <span class='material-symbols-outlined delete-icon' data-id='${job.ID_Offre}'>delete</span> <span class='material-symbols-outlined edit-icon' data-id='${job.ID_Offre}'>edit</span> </p>`;
                htmlContent += "</div>";
            });

            htmlContent += "</div>";
            document.getElementById('get_result').innerHTML = htmlContent;
            document.getElementById('result').innerHTML = result;
        }
    };
    http.send();
}

document.querySelectorAll('.ville-link').forEach(function(link) {
    link.addEventListener('click', function() {
        var ville = this.getAttribute('ville');
        chargerDonnees(ville);
    });
});

document.body.addEventListener('click', function(event) {
    // Gestion de la fermeture de la popup si l'élément cliqué est le bouton de fermeture
    if (event.target.classList.contains('close-btn')) {
        document.getElementById('editPopup').style.display = 'none';
        document.getElementById('newPopup').style.display = 'none';
    } 

    // Gestion de l'ouverture de la popup d'édition si l'icône d'édition est cliquée
    else if (event.target.classList.contains('edit-icon')) { 
        console.log("Modification d'une nouvelle offre");
        document.getElementById('editPopup').style.display = 'block';
        // Réinitialisation du formulaire d'édition si nécessaire
        document.getElementById('editOffreForm').reset();
    } 

    // Gestion de l'ouverture de la popup d'ajout si l'icône d'ajout est cliquée
    else if (event.target.classList.contains('add-icon')) { 
        console.log("Ajout d'une nouvelle offre");
        document.getElementById('newPopup').style.display = 'block';
        // Réinitialisation du formulaire d'ajout si nécessaire
        document.getElementById('nouvelleOffreForm').reset();
    }
});




document.getElementById('nouvelleOffreForm').addEventListener('submit', function(e) {
    e.preventDefault(); // Pour éviter la soumission standard du formulaire
  
    // Récupérer les valeurs du formulaire et les assigner à l'objet data
    var data = {
      ID_Entreprise: document.getElementById('idEntreprise').value,
      Competences: document.getElementById('competences').value,
      Localite: document.getElementById('localite').value,
      TypePromotion: document.getElementById('typePromotion').value,
      Duree: document.getElementById('duree').value,
      Remuneration: document.getElementById('remuneration').value,
      DateOffre: document.getElementById('dateOffre').value,
      NombrePlaces: document.getElementById('nombrePlaces').value,
      TitreDuStage: document.getElementById('titreStage').value,
      DescriptionDuStage: document.getElementById('descriptionStage').value
    };
  
    // Envoyer les données en POST à l'API
    fetch('http://localhost:3000/donnees', {
      method: 'POST', // ou 'PUT'
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    })
    .then(response => response.json())
    .then(data => {
      console.log('Success:', data);
      alert('Offre ajoutée avec succès');
      // Vous pouvez ici rediriger l'utilisateur ou afficher un message de succès
    })
    .catch((error) => {
      console.error('Error:', error);
      alert('Une erreur est survenue');
    });
  });
  

  document.body.addEventListener('click', function(event) {
    // Vérifie si l'élément cliqué est une icône de suppression
    if (event.target.classList.contains('delete-icon')) {
        const offreId = event.target.getAttribute('data-id');
        supprimerOffre(offreId);
    }
    // ... Autres gestionnaires ici ...
});

function supprimerOffre(id) {
    fetch(`http://localhost:3000/donnees?ID_Offre=${id}`, {
        method: 'DELETE',
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Erreur lors de la suppression de l\'offre');
        }
        return response.json();
    })
    .then(() => {
        alert('Offre supprimée avec succès');
        // Ici, vous pouvez rafraîchir la liste des offres ou faire autre chose
        chargerDonnees(); // Recharger les données pour mettre à jour l'affichage
    })
    .catch((error) => {
        console.error('Erreur:', error);
        alert('Une erreur est survenue lors de la suppression');
    });
}
  