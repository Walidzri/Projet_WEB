const express = require('express');
const mysql = require('mysql');
const cors = require('cors');

const app = express();
app.use(cors({ origin: '*' }));
app.use(express.json());

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'projet_web'
});

db.connect(err => {
  if (err) throw err;
  console.log('Connecté à la base de données MySQL!');
});

app.get('/', (req, res) => {
  res.send('API fonctionne');
});

function genererClauseWhere(query) {
  const whereClauses = [];
  const values = [];

  Object.keys(query).forEach(key => {
    // Ajoute une vérification pour s'assurer que la clé correspond à un champ valide de la table
    // Ceci est important pour la sécurité, pour éviter une injection SQL par le nom du champ.
    // Vous devrez lister tous les champs valides de votre table ici.
    const validFields = ['ID_Offre', 'ID_Entreprise', 'Competences', 'Localite', 'TypePromotion', 'Duree', 'Remuneration', 'DateOffre', 'NombrePlaces', 'TitreDuStage', 'DescriptionDuStage'];
    if (validFields.includes(key)) {
      whereClauses.push(`${key} = ?`);
      values.push(query[key]);
    }
  });

  return {
    whereClause: whereClauses.length ? ' WHERE ' + whereClauses.join(' AND ') : '',
    values
  };
}

app.get('/donnees', (req, res) => {
  let sqlQueryBase = 'SELECT * FROM offrestage';
  const { whereClause, values } = genererClauseWhere(req.query);

  const sqlQuery = sqlQueryBase + whereClause;

  db.query(sqlQuery, values, (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Erreur lors de la récupération des données');
    }
    res.json(result);
  });
});


// Ajouter une nouvelle offre
app.post('/donnees', (req, res) => {
  const data = req.body;
  let sqlQuery = 'INSERT INTO offrestage SET ?';

  db.query(sqlQuery, data, (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Erreur lors de l\'insertion des données');
    }
    res.status(201).json({ message: 'Données insérées avec succès' });
  });
});

// Supprimer une offre
app.delete('/donnees', (req, res) => {
  const { id } = req.params;
  const sqlQuery = 'DELETE FROM offrestage WHERE ID = ?';

  db.query(sqlQuery, id, (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Erreur lors de la suppression des données');
    }
    if (result.affectedRows === 0) {
      return res.status(404).send('Aucune offre trouvée avec cet ID');
    }
    res.status(200).json({ message: 'Offre supprimée avec succès' });
  });
});

// Modifier (mettre à jour) une offre
app.put('/donnees/:id', (req, res) => {
  const { id } = req.params;
  const data = req.body;
  let sqlQuery = 'UPDATE offrestage SET ? WHERE ID = ?';

  db.query(sqlQuery, [data, id], (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Erreur lors de la mise à jour des données');
    }
    if (result.affectedRows === 0) {
      return res.status(404).send('Aucune offre trouvée avec cet ID');
    }
    res.status(200).json({ message: 'Offre mise à jour avec succès' });
  });
});

// Démarrage du serveur
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Serveur démarré sur le port ${PORT}`);
});
