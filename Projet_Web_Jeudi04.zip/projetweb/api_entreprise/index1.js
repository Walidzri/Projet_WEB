const express = require('express');
const mysql = require('mysql');
const cors = require('cors'); // Importation du package cors

// Création de l'application Express
const app = express();

// Middleware pour autoriser les requêtes cross-origin
app.use(cors({
  origin: '*' // Spécifiez ici l'origine autorisée pour les requêtes CORS
  // Pour autoriser toutes les origines, vous pouvez utiliser '*'
  // origin: '*'
}));

// Middleware pour parser le body des requêtes en JSON
app.use(express.json());

// Configuration de la connexion à la base de données
const db = mysql.createConnection({
  host     : 'localhost', // Ou l'IP de votre serveur si votre base de données est sur un serveur distant
  user     : 'root', // Utilisateur de la base de données
  password : '', // Mot de passe de l'utilisateur de la base de données
  database : 'projet_web' // Nom de la base de données
});

// Connexion à la base de données
db.connect((err) => {
  if (err) throw err;
  console.log('Connecté à la base de données MySQL!');
});

// Route de test pour vérifier que notre API fonctionne
app.get('/', (req, res) => {
  res.send('API fonctionne');
});

// Route pour récupérer des données depuis MySQL
app.get('/donnees', (req, res) => {
  const sqlQuery = 'SELECT * FROM entreprise';
  db.query(sqlQuery, (err, result) => {
    if (err) throw err;
    res.json(result);
  });
});

// Démarrage du serveur
const PORT = 3001;
app.listen(PORT, () => {
  console.log(`Serveur démarré sur le port ${PORT}`);
});
