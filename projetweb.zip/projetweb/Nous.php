<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8" />
  <title>Get Job</title>
  <link rel="stylesheet" href="Nous.css" />
  <link rel="shortcut icon" href="projet/logosite.ico" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />

  <style>
    .display_user {
      margin-right: 2%;
      margin-left: -22%;
    }

    .account-button {
      margin-left: -13%;
      margin-right: 2%;
      position: relative;
    }

    .logout-menu {
      position: absolute;
      top: 100%;
      right: 0;
      background-color: white;
      display: none;
    }

    .logout-menu a {
      display: block;
      padding: 5px;
      text-decoration: none;
      color: #333;
      font-size: 17px;
    }

    .logout-menu a:hover {
      background-color: lightskyblue;
    }
  </style>

</head>

<header>
  <img src="logo.png" alt="Logo" />
  <nav>
    <ul>
      <li><a href="Accueil.php">Accueil </a></li>
      <li><a href="Entreprise.php">Entreprises </a></li>
      <li><a href="poffre.php">Offres</a></li>
      <li><a href="Nous.php">A propos de nous</a></li>
      <li><a href="Contact.php">Nous contacter</a></li>
    </ul>
  </nav>

  <div class="account-button" id="accountButton">
    <i class="fa-solid fa-user"></i>
    <div class="logout-menu" id="logoutMenu">
      <a href="logout.php">Déconnexion</a>
    </div>
  </div>

  <div class="display_user">
    <?php
    session_start();

    // Check if the user is logged in (i.e., if nom and prenom session variables are set)
    if (isset($_SESSION['nom']) && isset($_SESSION['prenom'])) {
      $nom = $_SESSION['nom'];
      $prenom = $_SESSION['prenom'];
      echo "$nom $prenom"; // Display a the user name message
    }
    ?>
  </div>

  <script src="logout.js" defer></script>

</header>

<body>
  <img class="nous texte" src="projet/nousimg.png" alt="Image" />
  <br /><br /><br /><br />

  <h1>Notre priorite c'est vous!</h1>
  <div class="aligne">
    <img src="projet/etudiant.jpg" alt="Image" />
    <p>
      Le stagiaire d’aujourd’hui est le salarié de demain. En effet, selon la
      conférence des Grandes Écoles, 30 % des étudiants issus d’écoles de
      commerce et d’ingénieurs trouvent leurs premiers emplois à l’issue d’un
      stage. Dénicher le stagiaire idéal est cependant périlleux, quelques
      outils vous seront alors utiles.
    </p>
  </div>
  <br /><br /><br />

  <h1>Qui sommes-nous?</h1>
  <div class="aligne">
    <p>
      Nous sommes Get Job, un site de recherche d'emploi specialise dans la
      recherche de stage visant les etudiants. GetJob est le premier site
      d’emploi mondial enregistrant plus de 350 millions+ de visiteurs uniques
      chaque mois. GetJob s’efforce de faire des candidats une priorité en
      leur permettant de chercher un emploi, de publier leur CV et de se
      renseigner au sujet des entreprises, le tout gratuitement. Chaque jour,
      nous offrons de nouvelles opportunités à des millions de personnes.
    </p>
    <img src="projet/direct.jpg" alt="Image" />
  </div>
  <br /><br /><br />

  <h1>Nos Collaborateurs</h1>
  <div class="aligne">
    <img src="projet/collab.jpg" alt="Image" />
    <p>
      Chez GetJob, notre mission consiste à aider les chercheurs d’emploi à
      décrocher le poste idéal. Nous comptons plus de 14 600 collaborateurs à
      travers le monde, chacun s’investissant à 100 % dans la poursuite de cet
      objectif et s’efforçant d’améliorer l’expérience de recrutement grâce au
      recueil de données et de témoignages authentiques. Nous favorisons un
      environnement de travail propice à la collaboration afin d’offrir la
      meilleure expérience aux chercheurs d’emploi.
    </p>
  </div>
  <br /><br /><br />

  <h1>Notre engagement</h1>
  <div class="aligne">
    <p>
      Pour créer un avenir professionnel équitable et inclusif, nous avons
      pris des engagements sur les plans environnementaux, sociaux et de
      gouvernance (ESG). En tant que premier site d’emploi au monde et
      première plateforme de matching et de recrutement, nous nous efforçons
      d’avoir un impact positif sur la société en aidant les chercheurs
      d’emploi à trouver un travail épanouissant.
    </p>
    <img src="projet/engagement.jpg" alt="Image" />
  </div>
  <br /><br /><br />

</body>

<footer class="site-footer">
  <div class="footer-container">
    <div class="footer-section">
      <h3>À propos</h3>
      <p>
        GetJob connecte les étudiants et les jeunes diplômés avec des
        opportunités de stage à travers le pays.
      </p>
    </div>
    <div class="footer-section">
      <h3>Nous contacter</h3>
      <ul>
        <li>
          <a href="mailto:contact@getjob.com">Email : contact@getjob.com</a>
        </li>
        <li><a href="tel:+1234567890">Téléphone : +123 456 7890</a></li>
      </ul>
    </div>
    <div class="footer-section">
      <h3>Liens rapides</h3>
      <ul>
        <li><a href="/privacy">Politique de confidentialité</a></li>
        <li><a href="/terms">Conditions d'utilisation</a></li>
      </ul>
    </div>
    <div class="footer-section">
      <h3>Suivez-nous</h3>
      <ul>
        <li><a href="#">Facebook</a></li>
        <li><a href="#">Twitter</a></li>
        <li><a href="#">LinkedIn</a></li>
      </ul>
    </div>
  </div>
</footer>

</html>