document.getElementById('accountButton').addEventListener('click', function () {
    var logoutMenu = document.getElementById('logoutMenu');
    logoutMenu.style.display = (logoutMenu.style.display === 'block') ? 'none' : 'block';
});
