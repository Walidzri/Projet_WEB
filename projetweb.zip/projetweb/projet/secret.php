<?php
$secret = "SECRET";
?>