<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="login.css" />
  <title>Page d'Authentification</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
</head>

<body>
  <main>
    <form id="loginForm" action="login1.php" method="POST">
      <input type="text" id="email" name="email" required placeholder="Nom d'utilisateur" />
      <div class="error-message" id="usernameError"></div>

      <div class="password-input">
        <input type="password" id="password" name="password" required placeholder="Mot de passe" />
        <div id="toggle"></div>
      </div>

      <button class="se_connecter" type="submit" required>
        Se connecter
      </button>
    </form>

    <div class="remember-me">
      <input type="checkbox" id="rememberMe" name="rememberMe" />
      <label for="rememberMe">Reste connecté</label>
    </div>

    <div class="forgot-password">
      <a href="P_reset.html">Mot de passe oublié ?</a>
    </div>

  </main>

  <script src="login.js"></script>

</body>

</html>