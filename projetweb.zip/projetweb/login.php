<?php
session_start(); // Démarre une nouvelle session ou reprend une session existante

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servername = "localhost";
    $username = "root"; // Utilisateur par défaut de MySQL dans XAMPP
    $password = ""; // Mot de passe par défaut de MySQL dans XAMPP est vide
    $dbname = "projet_web"; // Nom de votre base de données

    // Créer une connexion
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Vérifier la connexion
    if ($conn->connect_error) {
        die("Connexion échouée : " . $conn->connect_error);
    }

    $email = $_POST['email']; // Assurez-vous que le nom du champ correspond au nom dans le formulaire
    $motdepasse = $_POST['password'];

    // Sécuriser la requête pour prévenir les injections SQL
    $stmt = $conn->prepare("SELECT * FROM Utilisateur WHERE Email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        // Vérifier le mot de passe. Assurez-vous que le mot de passe dans votre base de données est haché.
        if (password_verify($motdepasse, $user['MotDePasse'])) {
            // Authentification réussie, enregistrer les infos de l'utilisateur dans la session
            $_SESSION['email'] = $user['Email'];
            $_SESSION['type'] = $user['Type']; // Vous pouvez également stocker le type d'utilisateur si nécessaire
            // Redirection vers une page spécifique après connexion réussie
            header("Location: login.php"); // Assurez-vous que ce chemin est correct
            exit();
        } else {
            echo "Échec de la connexion : mot de passe incorrect";
        }
    } else {
        echo "Échec de la connexion : utilisateur non trouvé";
    }

    $stmt->close();
    $conn->close();
}
?>