<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the email address from the form
    $email = $_POST["email"];

    // Validate the email address (you can add more robust validation)
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Generate a unique token for password reset (you may use a library for this)
        $token = bin2hex(random_bytes(32));

        // Store the token in the database along with the user's email (you need to implement this)
        // For demonstration purposes, let's assume we store it in a table called 'password_reset_tokens'
        // with columns 'email' and 'token'
        // Example SQL query: INSERT INTO password_reset_tokens (email, token) VALUES ('$email', '$token');

        // Send an email with the password reset link containing the token (you need to implement this)
        // Example email content:
        $subject = "Réinitialisation de votre mot de passe";
        $message = "Bonjour,\n\n";
        $message .= "Pour réinitialiser votre mot de passe, cliquez sur le lien suivant :\n";
        $message .= "http://example.com/reset_password.php?token=$token\n\n";
        $message .= "Si vous n'avez pas demandé de réinitialisation de mot de passe, ignorez simplement cet email.\n\n";
        $message .= "Cordialement,\nVotre équipe GetJob";
        $headers = "From: your@example.com"; // Change this to your email address
        mail($email, $subject, $message, $headers);

        // Redirect the user to a confirmation page
        header("Location: P_reset.php");
        exit();
    } else {
        // Email validation failed
        $emailError = "Veuillez entrer une adresse email valide.";
    }

    print ("hey! Anne");
}
?>