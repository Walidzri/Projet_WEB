var url = "http://localhost:3001/donnees";

var http = new XMLHttpRequest();
http.open("GET", url, true);
http.setRequestHeader("Content-type", "application/json");

http.onreadystatechange = function() {
    if(http.readyState == 4 && http.status == 200) {
        var responseData = JSON.parse(http.responseText);
        var jobs = responseData; // responseData est directement le tableau d'offres
        var htmlContent = "<div class='jobs-container'>";
        var result = "<h2><center> Résultats de vos recherches... "+ jobs.length + " résultat(s) </center></h2>";
        
        for (var i = 0; i < jobs.length; i++) {
            // Construction du HTML pour chaque offre
            htmlContent += "<div class='job-box'>";
            htmlContent += "<h3>" + (jobs[i].Nom ? jobs[i].Nom : 'Stage disponible') + "</h3>"; // Utilise TitreDuStage ou un titre générique si null
            htmlContent += "<div class='info-container'>";
            htmlContent += "<p><span class='material-symbols-outlined'>trending_up</span> Evaluation Stagiaire : " + jobs[i].EvaluationStagiaires + "</p>";
            htmlContent += "<p><span class='material-symbols-outlined'>trending_up</span> Evaluation Pilote : " + jobs[i].EvaluationPilote + "</p>";
            // Affiche la description ou indique qu'elle est indisponible si null
            htmlContent += "<p><span class='material-symbols-outlined'>domain</span>" + (jobs[i].SecteurActivite ? jobs[i].SecteurActivite : 'Description indisponible') + "</p>";
            htmlContent += "</div>"; // Ferme le conteneur info-container
            // Ajoute un bouton "Voir l'offre" (ajustez le lien selon vos besoins ou la logique de votre application)
            htmlContent += "<a href='details.html' class='voir-offre-btn' target='_blank'>Voir l'Entreprise</a>";
            htmlContent += "</div>"; // Ferme job-box
        }


        
        htmlContent += "</div>"; // Ferme le conteneur de jobs
        document.getElementById('get_result').innerHTML = htmlContent;
        document.getElementById('result').innerHTML = result;
    }
};

http.send();
