<?php include 'session.php'; ?>

<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="entreprise.css" />
  <title>Exemple de Page Web</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />

  <style>
    .display_user {
      margin-right: 2%;
      margin-left: -22%;
    }

    .account-button {
      margin-left: -13%;
      margin-right: 2%;
      position: relative;
    }

    .logout-menu {
      position: absolute;
      top: 100%;
      right: 0;
      background-color: white;
      display: none;
    }

    .logout-menu a {
      display: block;
      padding: 5px;
      text-decoration: none;
      color: #333;
      font-size: 17px;
    }

    .logout-menu a:hover {
      background-color: lightskyblue;
    }
  </style>

</head>

<header>
  <img src="logo.png" alt="Logo" />
  <nav>
    <ul>
      <li><a href="Accueil.php">Accueil </a></li>
      <li><a href="Entreprise.php">Entreprises </a></li>
      <li><a href="poffre.php">Offres</a></li>
      <li><a href="Nous.php">A propos de nous</a></li>
      <li><a href="Contact.php">Nous contacter</a></li>
    </ul>
  </nav>

  <div class="account-button" id="accountButton">
    <i class="fa-solid fa-user"></i>
    <div class="logout-menu" id="logoutMenu">
      <a href="logout.php">Déconnexion</a>
    </div>
  </div>


  <div class="display_user">
    <?php

    // Check if the user is logged in
    if (isset($_SESSION['nom']) && isset($_SESSION['prenom'])) {
      $nom = $_SESSION['nom'];
      $prenom = $_SESSION['prenom'];
      echo "$nom $prenom"; // Display a the user name 
    }
    ?>
  </div>
</header>

<body>
  <div class="main-container">
    <section id="filters">
      <h2>
        <center>
          Filtrer votre recherche pour des résultats plus ciblés
        </center>
      </h2>
      <form id="filterForm">
        <div class="filter">
          <label for="educationLevel">Niveau d'études :</label>
          <select id="educationLevel">
            <option value="all">Tous</option>
            <option value="bachelor">Licence</option>
            <option value="master">Master</option>
            <option value="phd">Doctorat</option>
          </select>
        </div>
        <div class="filter">
          <label for="internshipDuration">Durée de stage :</label>
          <select id="internshipDuration">
            <option value="all">Tous</option>
            <option value="1-3">1-3 mois</option>
            <option value="3-6">3-6 mois</option>
            <option value="6+">Plus de 6 mois</option>
          </select>
        </div>
        <div class="filter">
          <label for="sector">Secteur visé :</label>
          <select id="sector">
            <option value="all">Tous</option>
            <option value="tech">Technologie</option>
            <option value="finance">Finance</option>
            <option value="health">Santé</option>
          </select>
        </div>
        <div class="filter">
          <label for="remoteWork">Télétravail :</label>
          <select id="remoteWork">
            <option value="all">Tous</option>
            <option value="yes">Oui</option>
            <option value="no">Non</option>
          </select>
        </div>
        <div class="filter">
          <label for="function">Fonction :</label>
          <select id="function">
            <option value="all">Toutes</option>
            <option value="engineering">Ingénierie</option>
            <option value="marketing">Marketing</option>
            <option value="design">Design</option>
          </select>
        </div>

        <button type="submit">Appliquer les filtres</button>
      </form>
    </section>
    <main>
      <article>
        <div id="result"></div>

        <br />
        <div id="get_result"></div>
      </article>
      <article></article>
    </main>
  </div>
  <script src="entreprise.js"></script>
</body>

<footer class="site-footer">
  <div class="footer-container">
    <div class="footer-section">
      <h3>À propos</h3>
      <p>
        GetJob connecte les étudiants et les jeunes diplômés avec des
        opportunités de stage à travers le pays.
      </p>
    </div>
    <div class="footer-section">
      <h3>Nous contacter</h3>
      <ul>
        <li>
          <a href="mailto:contact@getjob.com">Email : contact@getjob.com</a>
        </li>
        <li><a href="tel:+1234567890">Téléphone : +123 456 7890</a></li>
      </ul>
    </div>
    <div class="footer-section">
      <h3>Liens rapides</h3>
      <ul>
        <li><a href="/privacy">Politique de confidentialité</a></li>
        <li><a href="/terms">Conditions d'utilisation</a></li>
      </ul>
    </div>
    <div class="footer-section">
      <h3>Suivez-nous</h3>
      <ul>
        <li><a href="#">Facebook</a></li>
        <li><a href="#">Twitter</a></li>
        <li><a href="#">LinkedIn</a></li>
      </ul>
    </div>
  </div>
</footer>

</html>