<?php include 'session.php'; ?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8" />
  <title>Get Job</title>
  <link rel="stylesheet" href="accueil.css" />
  <link rel="shortcut icon" href="projet/logosite.ico" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
</head>

<header>
  <img src="logo.png" alt="Logo" />
  <nav>
    <ul>
      <li><a href="Accueil.php">Accueil </a></li>
      <li><a href="Entreprise.php">Entreprises </a></li>
      <li><a href="poffre.php">Offres</a></li>
      <li><a href="Nous.php">A propos de nous</a></li>
      <li><a href="Contact.php">Nous contacter</a></li>
    </ul>
  </nav>

  <div class="account-button" id="accountButton">
    <i class="fa-solid fa-user"></i>
    <div class="logout-menu" id="logoutMenu">
      <a href="logout.php">Déconnexion</a>
    </div>
  </div>

  <div class="display_user">
    <?php

    // Check if the user is logged in (i.e., if nom and prenom session variables are set)
    if (isset($_SESSION['nom']) && isset($_SESSION['prenom'])) {
      $nom = $_SESSION['nom'];
      $prenom = $_SESSION['prenom'];
      echo "$nom $prenom"; // Display a the user name message
    }
    ?>
  </div>

  <script src="logout.js" defer></script>

</header>

<body>
  <div>
    <img class="acc" src="projet/background.png" alt="Image" />
  </div>

  <div class="carre">
    <form action="#" method="GET">
      <input class="recherche italic-text" type="text" name="Quoi" placeholder="mot-cle" />
      <input class="recherche italic-text" type="text" name="Où" placeholder="ville" />
      <button class="boutonrechercher bold-text" type="submit">
        Rechercher
      </button>
    </form>
  </div>

  <br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />

  <h1>Nos entreprises partenaires</h1>
  <hr />
  <br /><br />

  <div class="align">
    <div class="cadre">
      <img src="projet/engie.png" alt="Description de l'image" />
      <a href="https://www.engie.com/jobs/stages-alternance" target="_blank">
        <button type="button">Consulter</button>
      </a>
    </div>

    <div class="cadre">
      <img src="projet/VEULogo.png" alt="Description de l'image" />
      <a href="https://www.vinci-construction-projets.com/fr/nous-rejoindre/etudiants/" target="_blank">
        <button type="button">Consulter</button>
      </a>
    </div>

    <div class="cadre">
      <img src="projet/sg.png" alt="Description de l'image" />
      <a href="https://careers.societegenerale.com/stages" target="_blank">
        <button type="button">Consulter</button>
      </a>
    </div>

    <div class="cadre">
      <img src="projet/orange.png" alt="Description de l'image" />
      <a href="https://orange.jobs/site/fr-stages/index.htm" target="_blank">
        <button type="button">Consulter</button>
      </a>
    </div>
  </div>
  <br /><br />

  <h1>Les villes les plus recherches</h1>
  <hr />
  <br /><br />

  <div class="align">
    <a href="#">
      <img class="villeimg" src="projet/paris.png" alt="Paris" />
      <div class="villetxt bold-text">Paris</div>
    </a>

    <a href="#">
      <img class="villeimg" src="projet/london.png" alt="london" />
      <div class="villetxt bold-text">Londres</div>
    </a>

    <a href="#">
      <img class="villeimg" src="projet/madrid.png" alt="madrid" />
      <div class="villetxt bold-text">Madrid</div>
    </a>

    <a href="#">
      <img class="villeimg" src="projet/montreal.png" alt="montreal" />
      <div class="villetxt bold-text">Montreal</div>
    </a>
  </div>
  <br /><br />

  <h1>Les domaines les plus recherches</h1>
  <hr />
  <br /><br />

  <div class="align">
    <a href="#">
      <img class="villeimg" src="projet/info.png" alt="Informatique" />
      <div class="villetxt bold-text">Informatique</div>
    </a>

    <a href="#">
      <img class="villeimg" src="projet/btp.png" alt="Batiment" />
      <div class="villetxt bold-text">Batiment</div>
    </a>

    <a href="#">
      <img class="villeimg" src="projet/com.png" alt="Communication" />
      <div class="villetxt bold-text">Communication</div>
    </a>

    <a href="#">
      <img class="villeimg" src="projet/compta.png" alt="Marketing" />
      <div class="villetxt bold-text">Marketing</div>
    </a>
  </div>
  <br /><br />

</body>

<footer class="site-footer">
  <div class="footer-container">
    <div class="footer-section">
      <h3>À propos</h3>
      <p>
        GetJob connecte les étudiants et les jeunes diplômés avec des
        opportunités de stage à travers le pays.
      </p>
    </div>
    <div class="footer-section">
      <h3>Nous contacter</h3>
      <ul>
        <li>
          <a href="mailto:contact@getjob.com">Email : contact@getjob.com</a>
        </li>
        <li><a href="tel:+1234567890">Téléphone : +123 456 7890</a></li>
      </ul>
    </div>
    <div class="footer-section">
      <h3>Liens rapides</h3>
      <ul>
        <li><a href="/privacy">Politique de confidentialité</a></li>
        <li><a href="/terms">Conditions d'utilisation</a></li>
      </ul>
    </div>
    <div class="footer-section">
      <h3>Suivez-nous</h3>
      <ul>
        <li><a href="#">Facebook</a></li>
        <li><a href="#">Twitter</a></li>
        <li><a href="#">LinkedIn</a></li>
      </ul>
    </div>
  </div>
</footer>

</html>