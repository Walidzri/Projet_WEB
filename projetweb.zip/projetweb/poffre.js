function chargerDonnees(localite) {
    var urlBase = "http://localhost:3000/donnees";
    var url = urlBase + "?Localite=" + encodeURIComponent(localite);

    var http = new XMLHttpRequest();
    http.open("GET", url, true);
    http.setRequestHeader("Content-type", "application/json");

    http.onreadystatechange = function() {
        if(http.readyState == 4 && http.status == 200) {
            var responseData = JSON.parse(http.responseText);
            var jobs = responseData; // responseData est directement le tableau d'offres
            var htmlContent = "<div class='jobs-container'>";
            var result = `<h2><center> Résultats de vos recherches... ${jobs.length} résultat(s) pour ${localite}</center></h2>`;
            
            for (var i = 0; i < jobs.length; i++) {
                // Construction du HTML pour chaque offre
                htmlContent += "<div class='job-box'>";
                htmlContent += `<h3>${jobs[i].TitreDuStage ? jobs[i].TitreDuStage : 'Stage disponible'}</h3>`;
                htmlContent += "<div class='info-container'>";
                htmlContent += `<p><span class='material-symbols-outlined'>location_on</span> ${jobs[i].Localite}</p>`;
                htmlContent += `<p><span class='material-symbols-outlined'>calendar_month</span> ${new Date(jobs[i].DateOffre).toLocaleDateString()}</p>`;
                htmlContent += `<p><span class='material-symbols-outlined'>description</span> ${jobs[i].DescriptionDuStage ? jobs[i].DescriptionDuStage : 'Description indisponible'}</p>`;
                htmlContent += "<span class='material-symbols-outlined'>edit</span>";
                htmlContent += "</div>"; // Ferme le conteneur info-container
                htmlContent += "<a href='details.html' class='voir-offre-btn' target='_blank'>Voir l'offre</a>";
                htmlContent += "</div>"; // Ferme job-box
            }

            htmlContent += "</div>"; // Ferme le conteneur de jobs
            document.getElementById('get_result').innerHTML = htmlContent;
            document.getElementById('result').innerHTML = result;
        }
    };

    http.send();
}

chargerDonnees('Madrid'); // Appel de la fonction avec "Madrid" en paramètre



// Définissez la fonction à exécuter
function madrid() {
    alert("Le bouton a été cliqué !");
}

// Récupérez l'élément bouton par son ID
var bouton = document.getElementById("monBouton");

// Ajoutez un gestionnaire d'événement 'click' qui appelle maFonction()
bouton.onclick = maFonction;
