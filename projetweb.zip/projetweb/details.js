document.addEventListener('DOMContentLoaded', function() {
    // Extraction de l'ID de l'offre depuis l'URL
    const params = new URLSearchParams(window.location.search);
    const offreId = params.get('id');
    
    // URL de l'API pour récupérer les détails de l'offre (ajustez selon votre implémentation)
    const url = `http://localhost:3000/donnees/${offreId}`;

    // Récupération et affichage des détails de l'offre
    fetch(url)
    .then(response => response.json())
    .then(data => {
        document.getElementById('titre').textContent = data.TitreDuStage || 'Titre non disponible';
        document.getElementById('localite').textContent = data.Localite;
        document.getElementById('duree').textContent = `${data.Duree} mois`;
        document.getElementById('remuneration').textContent = `${data.Remuneration} €`;
        document.getElementById('competences').textContent = data.Competences;
        document.getElementById('description').textContent = data.DescriptionDuStage || 'Description non disponible';
    })
    .catch(error => console.error('Erreur lors de la récupération des données:', error));
});


// Code existant pour charger les détails de l'offre

