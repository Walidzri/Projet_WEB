<?php
session_start(); // Démarre une nouvelle session ou reprend une session existante

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    //retrieve from data
    $email = $_POST['email'];
    $password = $_POST['password'];

    //database connection
    $servername = "localhost";
    $dbemail = "root"; // Utilisateur par défaut de MySQL dans XAMPP
    $dbpassword = ""; // Mot de passe par défaut de MySQL dans XAMPP est vide
    $dbname = "projet_web"; // Nom de votre base de données

    // Créer une connexion
    $conn = new mysqli($servername, $dbemail, $dbpassword, $dbname);

    // Vérifier la connexion
    if ($conn->connect_error) {
        die("Connexion échouée : " . $conn->connect_error);
    }

    //validate login authentification
    $query = "SELECT * FROM utilisateur WHERE email='$email' AND Motdepasse='$password'";
    $result = $conn->query($query);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();


        //login success
        $_SESSION['email'] = $email;
        $_SESSION['nom'] = $row['Nom'];
        $_SESSION['prenom'] = $row['Prenom'];



        header("Location: Accueil.php");
        exit();
    } else {
        //login failed
        echo "Le nom d'utilisateur ou le mot de passe est incorrect.";
    }

    $conn->close();

} elseif (isset($_SESSION['email'])) {
    // If the session variable 'email' is set, it means the user is already logged in
    header("Location: Accueil.php");
    exit();
}
?>