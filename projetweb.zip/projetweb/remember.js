// Get the checkbox element
const rememberMeCheckbox = document.getElementById('rememberMe');

// Add event listener to checkbox
rememberMeCheckbox.addEventListener('change', function() {
    // Check if the checkbox is checked
    if (this.checked) {
        // Perform action when checkbox is checked
        alert('You are now remembered!');
    } else {
        // Perform action when checkbox is unchecked
        alert('You are not remembered anymore!');
    }
});
