document
  .querySelector('input[name="tel"]')
  .addEventListener("input", function (event) {
    let inputValue = event.target.value;
    let numericValue = inputValue.replace(/\D/g, "");
    event.target.value = numericValue;
  });

const fileInputs = document.querySelectorAll('input[type="file"]');
fileInputs.forEach((input) => {
  input.addEventListener("change", function (event) {
    const fileList = event.target.files;
    const fileName =
      fileList.length > 0 ? fileList[0].name : "No file chosen yet.";
    const customText = event.target.nextElementSibling.nextElementSibling;
    customText.textContent = fileName;
  });
});