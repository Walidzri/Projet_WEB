document
        .getElementById("username")
        .addEventListener("input", function () {
          var usernameInput = this.value;
          var emailError = document.getElementById("emailError");

          if (!isValidEmail(usernameInput)) {
            emailError.textContent =
              "Veuillez entrer une adresse e-mail valide.";
          } else {
            emailError.textContent = ""; // Efface le message d'erreur s'il est valide
          }
        });

      function isValidEmail(email) {
        // Utilisation d'une expression régulière simple pour vérifier si c'est un email
        var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
      }

window.onload = function() {
    var storedEmail = localStorage.getItem('storedEmail');
    var storedPassword = localStorage.getItem('storedPassword');

    if (storedEmail && storedPassword) {
        document.getElementById('email').value = storedEmail;
        document.getElementById('password').value = storedPassword;
    }
};

// Save email and password to localStorage when form is submitted
document.getElementById('loginForm').addEventListener('submit', function() {
    var email = document.getElementById('email').value;
    var password = document.getElementById('password').value;

    // Check if "Remember Me" checkbox is checked
    if (document.getElementById('rememberMe').checked) {
        localStorage.setItem('storedEmail', email);
        localStorage.setItem('storedPassword', password);
    } else {
        // If "Remember Me" is not checked, clear the stored values
        localStorage.removeItem('storedEmail');
        localStorage.removeItem('storedPassword');
    }
});

// Validation for email input
document.getElementById('email').addEventListener('input', function () {
    var usernameInput = this.value;
    var emailError = document.getElementById('emailError');

    if (!isValidEmail(usernameInput)) {
        emailError.textContent = "Veuillez entrer une adresse e-mail valide.";
    } else {
        emailError.textContent = ""; // Efface le message d'erreur s'il est valide
    }
});

function isValidEmail(email) {
    // Utilisation d'une expression régulière simple pour vérifier si c'est un email
    var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}


document.getElementById("email").addEventListener("input", function () {
    var usernameInput = this.value;
    var emailError = document.getElementById("emailError");

    if (!isValidEmail(usernameInput)) {
        emailError.textContent = "Veuillez entrer une adresse e-mail valide.";
    } else {
        emailError.textContent = ""; // Efface le message d'erreur s'il est valide
    }
    });

    function isValidEmail(email) {
    // Utilisation d'une expression régulière simple pour vérifier si c'est un email
        var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    const showPassword = document.querySelector("#show-password");
    const passwordField = document.querySelector("#password");

    showPassword.addEventListener("click", function () {
    // Toggle between showing and hiding the password
    const type =
        passwordField.getAttribute("type") === "password"
            ? "text"
            : "password";
        passwordField.setAttribute("type", type);

    // Toggle between different eye icons based on the password visibility
    if (type === "password") {
        this.classList.remove("fa-eye");
        this.classList.add("fa-eye-slash");
    } else {
        this.classList.remove("fa-eye-slash");
        this.classList.add("fa-eye");
}});
    



