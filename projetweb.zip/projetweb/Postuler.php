<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <title>Postuler</title>
  <link rel="stylesheet" type="text/css" href="Postuler.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />

  <style>
    .display_user {
      margin-right: 2%;
      margin-left: -22%;
    }

    .account-button {
      margin-left: -13%;
      margin-right: 2%;
      position: relative;
    }

    .logout-menu {
      position: absolute;
      top: 100%;
      right: 0;
      background-color: white;
      display: none;
    }

    .logout-menu a {
      display: block;
      padding: 5px;
      text-decoration: none;
      color: #333;
      font-size: 17px;
    }

    .logout-menu a:hover {
      background-color: lightskyblue;
    }
  </style>

</head>

<header>
  <img src="logo.png" alt="Logo" />
  <nav>
    <ul>
      <li><a href="Accueil.php">Accueil </a></li>
      <li><a href="Entreprise.php">Entreprises </a></li>
      <li><a href="poffre.php">Offres</a></li>
      <li><a href="Nous.php">A propos de nous</a></li>
      <li><a href="Contact.php">Nous contacter</a></li>
    </ul>
  </nav>

  <div class="account-button" id="accountButton">
    <i class="fa-solid fa-user"></i>
    <div class="logout-menu" id="logoutMenu">
      <a href="logout.php">Déconnexion</a>
    </div>
  </div>

  <div class="display_user">
    <?php

    // Check if the user is logged in (i.e., if nom and prenom session variables are set)
    if (isset($_SESSION['nom']) && isset($_SESSION['prenom'])) {
      $nom = $_SESSION['nom'];
      $prenom = $_SESSION['prenom'];
      echo "$nom $prenom"; // Display a the user name message
    }
    ?>
  </div>

  <script src="logout.js" defer></script>
</header>

<body>
  <div class="container">
    <form action="Confirm.html" method="post">
      <h2>Mes informations</h2>

      <div class="content">
        <div class="input-box">
          <label style="padding-top: 15px" for="Nom">Nom</label>
          <input type="text" placeholder="Entrer votre nom" name="nom" required />
        </div>

        <div class="input-box">
          <label style="padding-top: 15px" for="Prenom">Prénom</label>
          <input type="text" placeholder="Entrer votre prénom" name="prenom" required />
        </div>

        <div class="input-box">
          <label style="padding-top: 10px" for="Email">E-mail</label>
          <input type="email" placeholder="Entrer votre e-mail" name="email" required />
        </div>

        <div class="input-box">
          <label style="padding-top: 10px" for="Telephone">Téléphone</label>
          <input type="tel" placeholder="Entrer votre numéro de tél" name="tel" pattern="[0-9]*"
            title="Veuillez entrer un numéro de téléphone valide." required />
        </div>

        <div class="input-box">
          <label style="padding-top: 10px" for="Adresse">Adresse</label>
          <input type="text" placeholder="Entrer votre adresse" name="adresse" required />
        </div>
      </div>

      <h2>Mon Parcours</h2>
      <div class="Docs" style="
            background-color: rgb(203, 203, 203);
            width: 90%;
            padding-top: 27px;
            padding-bottom: 10px;
          ">
        <div class="button-container">
          <label for="CV">CV *</label>
          <input type="file" id="cvFile" required />
          <label for="cvFile" class="upload-label">Ajouter<i class="fas fa-upload"></i></label>
          <span class="custom-text"><b>No file chosen yet.</b></span>
        </div>

        <div class="button-container">
          <label for="Lettre_de_motivation">Lettre de motivation</label>
          <input type="file" id="motif_File" />
          <label for="motif_File" class="upload-label">Ajouter<i class="fas fa-upload"></i></label>
          <span class="custom-text"><b>No file chosen yet.</b></span>
        </div>
      </div>

      <h2>Mes Liens Internet</h2>
      <div class="Links" style="
            background-color: rgb(203, 203, 203);
            width: 90%;
            padding-top: 27px;
            padding-bottom: 10px;
          ">
        <div class="input-box">
          <label for="LinkedIn">LinkedIn</label>
          <input type="text" name="LinkedIn" />
        </div>
        <div class="input-box">
          <label for="Site_Internet">Site Internet</label>
          <input type="text" name="Site_Internet" />
        </div>
      </div>

      <div style="margin-left: 30%">
        <button type="submit">
          <a href="Confirm.html" style="text-decoration: none; color: white">Soumettre ma candidature</a>
        </button>
      </div>
    </form>
  </div>

  <script src="Postuler.js"></script>
</body>

<footer class="site-footer">
  <div class="footer-container">
    <div class="footer-section">
      <h3>À propos</h3>
      <p>
        GetJob connecte les étudiants et les jeunes diplômés avec des
        opportunités de stage à travers le pays.
      </p>
    </div>
    <div class="footer-section">
      <h3>Nous contacter</h3>
      <ul>
        <li>
          <a href="mailto:contact@getjob.com">Email : contact@getjob.com</a>
        </li>
        <li><a href="tel:+1234567890">Téléphone : +123 456 7890</a></li>
      </ul>
    </div>
    <div class="footer-section">
      <h3>Liens rapides</h3>
      <ul>
        <li><a href="/privacy">Politique de confidentialité</a></li>
        <li><a href="/terms">Conditions d'utilisation</a></li>
      </ul>
    </div>
    <div class="footer-section">
      <h3>Suivez-nous</h3>
      <ul>
        <li><a href="#">Facebook</a></li>
        <li><a href="#">Twitter</a></li>
        <li><a href="#">LinkedIn</a></li>
      </ul>
    </div>
  </div>
</footer>

</html>