<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <title>Contact Us | Get Job</title>
  <link rel="stylesheet" href="Contact.css" />
  <link rel="shortcut icon" href="projet/logosite.ico" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
  <title>Contact</title>

  <style>
    .display_user {
      margin-right: 2%;
      margin-left: -22%;
    }

    .account-button {
      margin-left: -13%;
      margin-right: 2%;
      position: relative;
    }

    .logout-menu {
      position: absolute;
      top: 100%;
      right: 0;
      background-color: white;
      display: none;
    }

    .logout-menu a {
      display: block;
      padding: 5px;
      text-decoration: none;
      color: #333;
      font-size: 17px;
    }

    .logout-menu a:hover {
      background-color: lightskyblue;
    }
  </style>

</head>

<body>
  <header>
    <img src="logo.png" alt="Logo" />
    <nav>
      <ul>
        <li><a href="Accueil.php">Accueil </a></li>
        <li><a href="Entreprise.php">Entreprises </a></li>
        <li><a href="poffre.php">Offres</a></li>
        <li><a href="Nous.php">A propos de nous</a></li>
        <li><a href="Contact.php">Nous contacter</a></li>
      </ul>
    </nav>

    <div class="account-button" id="accountButton">
      <i class="fa-solid fa-user"></i>
      <div class="logout-menu" id="logoutMenu">
        <a href="logout.php">Déconnexion</a>
      </div>
    </div>

    <div class="display_user">
      <?php
      session_start();

      // Check if the user is logged in (i.e., if nom and prenom session variables are set)
      if (isset($_SESSION['nom']) && isset($_SESSION['prenom'])) {
        $nom = $_SESSION['nom'];
        $prenom = $_SESSION['prenom'];
        echo "$nom $prenom"; // Display a the user name message
      }
      ?>
    </div>

    <script src="logout.js" defer></script>

  </header>

  <div class="contact-form-container">
    <h1>Contactez-nous</h1>
    <p>(*) Champs obligatoire</p>
    <form action="/votre-page-de-traitement" method="post" class="contact-form">
      <div class="form-group">
        <label for="objet">Objet *:</label>
        <input type="text" id="objet" name="objet" required />
      </div>
      <div class="form-group">
        <label for="nom">Nom *:</label>
        <input type="text" id="nom" name="nom" required />
      </div>
      <div class="form-group">
        <label for="prenom">Prenom *:</label>
        <input type="text" id="prenom" name="prenom" required />
      </div>
      <div class="form-group">
        <label for="email">Adresse-email *:</label>
        <input type="email" id="email" name="email" required />
      </div>
      <div class="form-group">
        <label for="formation">Formation en cours *:</label>
        <input type="text" id="formation" name="formation" required />
      </div>
      <div class="form-group">
        <label for="specialite">Spécialité:</label>
        <input type="text" id="specialite" name="specialite" />
      </div>
      <div class="form-group">
        <label for="message">Votre message *:</label>
        <textarea id="message" name="message" required></textarea>
      </div>
      <button type="submit" class="submit-button">Envoyer</button>
    </form>
  </div>

</body>

<footer class="site-footer">
  <div class="footer-container">
    <div class="footer-section">
      <h3>À propos</h3>
      <p>
        GetJob connecte les étudiants et les jeunes diplômés avec des
        opportunités de stage à travers le pays.
      </p>
    </div>
    <div class="footer-section">
      <h3>Nous contacter</h3>
      <ul>
        <li>
          <a href="mailto:contact@getjob.com">Email : contact@getjob.com</a>
        </li>
        <li><a href="tel:+1234567890">Téléphone : +123 456 7890</a></li>
      </ul>
    </div>
    <div class="footer-section">
      <h3>Liens rapides</h3>
      <ul>
        <li><a href="/privacy">Politique de confidentialité</a></li>
        <li><a href="/terms">Conditions d'utilisation</a></li>
      </ul>
    </div>
    <div class="footer-section">
      <h3>Suivez-nous</h3>
      <ul>
        <li><a href="#">Facebook</a></li>
        <li><a href="#">Twitter</a></li>
        <li><a href="#">LinkedIn</a></li>
      </ul>
    </div>
  </div>
</footer>

</html>