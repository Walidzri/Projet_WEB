<?php
session_start();

// Vérifie si l'utilisateur n'est pas connecté, alors redirigez-le vers la page de connexion
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}
?>